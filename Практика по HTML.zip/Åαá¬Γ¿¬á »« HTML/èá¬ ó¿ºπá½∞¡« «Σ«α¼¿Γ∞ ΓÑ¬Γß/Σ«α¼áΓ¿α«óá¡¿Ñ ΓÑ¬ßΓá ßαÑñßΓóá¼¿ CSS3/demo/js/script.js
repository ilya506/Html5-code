const elems = document.querySelectorAll('.parallax');
const parlx = new Parlx(elems);
